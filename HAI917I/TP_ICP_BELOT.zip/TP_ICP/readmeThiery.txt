This code was inspired from "gMini", provided by Pr. Tamy Boubekeur at : http://perso.telecom-paristech.fr/~boubek/#code
