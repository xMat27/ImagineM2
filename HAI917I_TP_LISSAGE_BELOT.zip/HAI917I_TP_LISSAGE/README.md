# HAI702I_tp
Code derived from GMINI
-----------

Author: Tamy Boubekeur (https://perso.telecom-paristech.fr/boubek/)


Description
------------

gmini is a small 3D "tester" program, with minimum interaction. 
Just replace the loading and/or drawing function for testing your algorithm, or visualize your particular format.


Installation
------------

This is an alpha release, you may have to set up the makefile with
your lib/include path and options.


Compilation 
------------
make


Execution 
------------
./tp
