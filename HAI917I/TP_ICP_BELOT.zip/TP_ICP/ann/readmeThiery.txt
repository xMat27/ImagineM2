I put the source code only, if you want to build the library, please visit:
https://www.cs.umd.edu/~mount/ANN/
